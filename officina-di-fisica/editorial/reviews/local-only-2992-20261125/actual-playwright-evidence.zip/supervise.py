"""Resource supervision only; invokes the unchanged canonical preview protocol."""
import fcntl,hashlib,json,os,re,shutil,signal,subprocess,time
from pathlib import Path
APP=Path.cwd();OUT=APP/'output/playwright/local-only-2992';LOG=OUT/'actual-run.log';RECEIPT=OUT/'resource-receipt.json'
def memory_free():
 p=subprocess.run(['memory_pressure','-Q'],capture_output=True,text=True,check=True)
 return int(re.search(r'free percentage:\s*(\d+)%',p.stdout)[1])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with open('/private/tmp/cric-bounded-local-work.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 free=shutil.disk_usage('/private/tmp').free;memory=memory_free()
 if free<3*1024**3 or memory<30:raise RuntimeError('Initial resource guard refused before browser launch')
 request=json.loads((APP.parent/'.github/cric-preintegration-request.json').read_text());registry=APP/'editorial/batches/registry.json';registry_sha=digest(registry)
 if registry_sha!=request['registrySha256']:raise RuntimeError('Registry/request differs before local run')
 for name,pin in request['protocolFiles'].items():
  if digest(APP/name)!=pin:raise RuntimeError('Canonical protocol changed')
 env={**os.environ,'PATH':'/private/tmp/cric-recovery-venv/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','ASTRA_RESULTS':str(OUT),'ASTRA_BROWSER_WORKERS':'1'}
 expected=len(json.loads(registry.read_text())['batches'])+sum(bool(r.get('revisionPackage')) for r in json.loads(registry.read_text())['activityBatches'])
 start=time.monotonic();observations=[];stop=None
 with LOG.open('w') as output:
  child=subprocess.Popen(['node','tests/corpus/browser-batches.mjs'],cwd=APP,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  while child.poll() is None:
   free=shutil.disk_usage('/private/tmp').free;memory=memory_free();observations.append({'seconds':round(time.monotonic()-start,1),'freeDiskBytes':free,'memoryFreePercent':memory})
   if free<2*1024**3 or memory<12 or time.monotonic()-start>1200:
    stop='RESOURCE_OR_DURATION_GUARD';os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=30)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(5)
  code=child.wait()
 summary=None
 if code==0:
  for line in LOG.read_text().splitlines():
   try:value=json.loads(line)
   except ValueError:continue
   if isinstance(value,dict) and 'batches' in value:summary=value
  if not summary or summary.get('batches')!=expected or summary.get('failed')!=0 or summary.get('registrySha256')!=registry_sha or digest(registry)!=registry_sha:raise RuntimeError('Actual global summary or immutable registry mismatch')
 receipt={'scope':'Local-only resource-supervised invocation of unchanged canonical Playwright runner; not remote CI or publication','expectedBatches':expected,'processExitCode':code,'supervisorStop':stop,'actualGlobalSummary':summary,'initialDiskBytes':observations[0]['freeDiskBytes'],'initialMemoryFreePercent':observations[0]['memoryFreePercent'],'minimumDiskBytes':min(o['freeDiskBytes'] for o in observations),'minimumMemoryFreePercent':min(o['memoryFreePercent'] for o in observations),'observations':observations,'actualLogSha256':digest(LOG),'supervisorSha256':digest(Path(__file__)),'uploads':False,'humanApproval':'NOT_RUN','publicationAction':'NONE'}
 RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='observations'}),flush=True)
 raise SystemExit(code if code>=0 else 128-code)
