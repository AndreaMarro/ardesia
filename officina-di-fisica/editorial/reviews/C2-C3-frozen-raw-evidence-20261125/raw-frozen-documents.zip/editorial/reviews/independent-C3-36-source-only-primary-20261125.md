# C3: primaria indipendente source-only36

Solo locale, nessun push/upload. Nessuna approvazione umana o credito. Input projection SHAa2868bb74fe085f909d55060e6fafbe093f9c070c67474a2a1512808d40feb88. Sorgente Git5d1dc8dc7b601aef959d10d564c75462be74708d, esperienze-C3.json SHA2738799d5195ca5eda77c4dce1cdc79f708237e5660bb9cabcc7fac4f80ea3ff.

Previously reviewed historical thermal lessons/examples and incidentally read shared orologi.js, which contains some C3 ramp/heat-input/time laws. No claim of full blinding. In this new phase modelli/C3.js and solution-bearing fields of these36 have not been read.

L’allowlist esclude measure/output, formula, substitution, interpretation, blocks, ordinate di riferimento, prediction e implementation. I risultati qui sono derivazioni mie dal problema visibile: non sono chiavi sorgente e non provano ancora le due domande effettivamente generate. Nessun modelli/C3.js o campo risolutivo di questi36 è stato letto in questa fase.

Condizioni da chiudere dopo il freeze: valore diσ/materiale studente per irraggiamento;273.15K esatto contro eventuale approssimazione dichiarata; reversibilità necessaria all’adiabatica; segno calore acqua; cap100g del ghiaccio; volumi assoluti positivi nella compressione; limiti di temperatura/secondo principio; conteggi interi e direzione spontanea. Simboli ln/sqrt non saranno considerati risposta manuale fruibile se il graderNumber li rifiuta: servirà valutare le due domande reali e una procedura numerica effettiva.

- **SIM-C3-L01-01**: V=20+10s. Closed gas, piston outward positive, fixed10cm² section. Volume gain is area times stroke. No mass crosses; heat/work cannot be inferred numerically without further data. Multiply stroke by10 then add20; inverse s=(V−20)/10. V20..100cm³ stays positive.

- **SIM-C3-L01-02**: p=(2/5)T. Fixed amount and rigid volume, absolute temperature and pressure. Working sensor coefficient0.4kPa/K assigned, not a Celsius-origin law. Multiply T by2 then divide5; T200..500K gives p80..200kPa.

- **SIM-C3-L01-03**: p=120/V. Closed ideal gas at fixed positive T; nRT120kPa·L given. Final equilibrium pressure is path-independent, not a claim Q or W is a state function. Divide120 by positive V1..5L; inverse V=120/p. kPa·L=J.

- **SIM-C3-L01-04**: T_K=theta_C+27315/100. Exact Celsius/Kelvin offset273.15. A working273 approximation would need actual student-visible qualification; it has not been assumed here. Add273.15; differences10°C and10K agree without an offset. Absolute temperature remains223.15..373.15K.

- **SIM-C3-L02-01**: p=240/V. Closed ideal gas, isothermal equilibrium endpoints and constantpV240kPa·L. V1..8L remains positive. Reference2L→120kPa and6L→40kPa; inverse volume from240/p. Pressure halves on doubling volume.

- **SIM-C3-L02-02**: T=(5/2)p. Fixed amount and rigid volume, given V/(nR)=2.5K/kPa. p is explicitly absolute, not gauge. Multiply p by5 then divide2; p50..200kPa gives125..500K.

- **SIM-C3-L03-01**: Q=50 deltaT. Assigned total heat capacity50J/K held constant over the range; process/phase assumptions must match the full context. DeltaT is a difference, not an absolute temperature. Multiply by50; reference2→100J and8→400J. Zero increment needs zero modeled heat.

- **SIM-C3-L03-02**: C=(2/5)m_g. Same material with assigned specific heat0.4J/(gK), hence400J/(kgK). Total capacity scales with mass; specific heat does not. Multiply grams by2/5. Reference100→40J/K and250→100J/K.

- **SIM-C3-L03-03**: Q_p−Q_v=nR deltaT=(4157/500)deltaT. One mole of fixed-composition ideal gas, two paths with the same initial state and same temperature increment. Mayer Cp−Cv=R; no monatomic assumption needed.8.314 is the explicitly assigned working R. Use8+0.314 per kelvin or integer4157/500. Difference equals extra expansion work; internal-energy differences agree.

- **SIM-C3-L03-04**: T_f=(80m+4000)/(m+200). Mixing water, common constant specific heat model, no vessel heat or losses. Temperature differences allow Celsius in this weighted average. If c(T) is retained, an integral balance would replace this model. Balance m(80−Tf)=200(Tf−20). Reference100→40°C and200→50°C. Positive masses keep20<Tf<80; inverse m=200(Tf−20)/(80−Tf).

- **SIM-C3-L04-01**: m_fused=(500/167)Q_kJ. Ice initially at0°C, latent heat334J/g assigned. Available ice mass must be at least the melted mass; total initial mass/power is not visible in the safe prompt. Convert kJ toJ then divide334:8.35kJ→25g,16.7→50g. At33.4kJ result100g if that much ice is available. No clock law derived here.

- **SIM-C3-L04-02**: Q_system=(113/50)m_vapor_signed. Positive signed mass is liquid→vapour; negative is condensation. Standard heat-into-water sign used conditionally; full bank convention must be read before acceptance. Multiply signed grams by2.26kJ/g. Reference−2→−4.52kJ,3→6.78kJ; opposite environment heat has opposite sign.

- **SIM-C3-L04-03**: m_fused=min(100,max(0,(50/17)(Q_kJ−2))). Exactly100g ice and assigned initial sensible-heat cost2kJ, latent340J/g=.34kJ/g. No melting below2kJ, partial melt2..36, full100g above36; further heat cannot melt more than100g. Subtract2kJ only in partial phase, convert units, divide. Reference1→0g and19→50g. Post-melt water temperature needs additional heat-capacity data; no clock power assumed.

- **SIM-C3-L05-01**: P=20/d_cm. Steady one-dimensional Fourier conduction, homogeneous constantk1W/(mK), area.01m², endpoint difference20K, positive thickness. d_cm/100 metres; kA deltaT/d=.2/(d/100). Reference2cm→10W,5cm→4W.

- **SIM-C3-L05-02**: P=42 mass_flow_g_per_s. Fixed42J released per gram in exchanger; constant flow, no extra mechanical/kinetic-energy term. Sign is heat delivered to second circuit. J/g times g/s is W. Reference1→42W and3→126W; no specific heat or10K drop inferred as a new given.

- **SIM-C3-L05-03**: j_out=sigma(T_s^4−300^4). Black surface emissivity1, positive absolute temperatures, net outward flux convention. Sigma value is not given in this safe projection; numerical use and manual feasibility remain conditional on full learner material. Factor10^8 using(T/100)^4−3^4 rather than huge fourth powers. At300K flux0;400K gives17500000000sigma. Cooler surface has negative outward flux, not negative absolute emitted power.

- **SIM-C3-L06-01**: deltaU=Q−W_by_gas=Q−10. Closed gas, work by gas positive, given fixed10J. Ignore bulk kinetic/potential changes. A feasible positive initial internal energy is needed over the full negative-change range. Subtract10 with signs; reference10→0J and30→20J. Heat leaving is not made positive by an absolute value.

- **SIM-C3-L06-02**: deltaU=12 deltaT. Assigned totalnCv12J/K, fixed ideal-gas amount and working capacity. DeltaT sign controls deltaU; formula does not independently specify the heat/work path. Multiply by12;−10→−120J,20→240J. Initial absolute T must keep final T positive.

- **SIM-C3-L06-03**: Q=deltaU+W_by_gas=10+W. Single process with deltaU10J; not a completed engine cycle just because prompt uses the word motore. Work sign is by gas. Add10;−10J work→Q0 (adiabatic compression possible),20→Q30J.

- **SIM-C3-L06-04**: W_by_gas=100 deltaV_L. Constant100kPa external pressure, quasistatic boundary-work model. Positive expansion, negative compression. Initial absolute volume must exceed1L if the−1L boundary is reachable. 1kPa·L=1J. Reference−.5L→−50J and1.5L→150J. No absolute V is visible in safe input.

- **SIM-C3-L07-01**: W_N=100 sum_(j=1..N)1/(N+j). Integer N1..8, Vi1L,Vf2L, equal volume increments1/N, prescribed external step pressures. Each pressure applies over its corresponding expansion step. Each step contributes100/(N+j)J. N1→50J,N2→175/3J. Finite sums can use hand long division with bounded rounding. Reversible limit100ln2 is separate and is not presumed an assigned numeric task.

- **SIM-C3-L07-02**: p=100/V. Closed fixed-temperature ideal gas with givenpV100kPa·L, positive volumes1..4L. Summary mentions compression; actual path capability must be checked later. Divide100 byV. Reference1→100kPa,2→50kPa; path direction does not alter endpoint law.

- **SIM-C3-L07-03**: p=(1/2)T. Rigid closed ideal gas, absolute state150kPa/300K, fixedn/V. No moving-boundary work. Scale pressure with absolute T;250→125kPa,400→200kPa. No Celsius ratio.

- **SIM-C3-L07-04**: V=T/100. Closed ideal gas at fixed positive pressure, reference3L at300K. Thermal expansion may be heating or cooling, but amount remains fixed. 3T/300L;250→2.5L,400→4L. Inverse T=100V.

- **SIM-C3-L07-05**: IF reversible/quasistatic nondissipative ideal-gas adiabat: p=100/(r sqrt(r)). Adiabatic Q0 alone is insufficient forpV^gamma constant. Full source/consumer must establish the isentropic/reversible ideal-gas assumptions and constantgamma3/2. At r1 pressure100kPa; r4 gives12.5kPa by exactsqrt4. Any generated non-perfect-square ratio needs an actually usable manual decimal method for Number grading; an exact radical alone is not sufficient.

- **SIM-C3-L08-01**: W_clockwise=60 deltaV_L. Rectangular clockwisep–V loop, pressure span60kPa. Nonnegative width0..3L; zero width is a degenerate zero-work limit. Rectangle area and1kPa·L=1J:1L→60J,2→120J. Reversing cycle direction would reverse sign, not absolute heat amounts.

- **SIM-C3-L08-02**: W=100−Q_cold_out. Completed cycle returns internal energy to its initial value.100J enters, xJ leaves to cold source. Temperatures are absent here, so any claimed efficiency must later respect actual reservoir Carnot bound. Subtract rejected heat:40→60J,80→20J. At100J rejected, work0; heat-out is a positive magnitude here.

- **SIM-C3-L08-03**: W_total=20N. Integer complete cycles, fixed20J output per turn, no residual internal-energy accumulation per completed cycle. Multiply turn count by20;2→40J,5→100J. Work accumulates while the state returns.

- **SIM-C3-L09-01**: Q_hot_min=(3/2)Q_cold;W_min=Q_cold/2. Reversible refrigerator with positive absolute Th/Tc3/2. Reservoir entropy balance and energy balance apply; irreversible operation requires at least this heat rejection for fixedQc. Multiply removed heat by1.5:20→30J,60→90J. Qc0 is zero operation; do not evaluate a0/0 COP there.

- **SIM-C3-L09-02**: W=(3/10)Q_hot. Given fixed30% engine efficiency; input heat nonnegative. Rejected heat0.7Qh; any actual reservoir temperatures must permit that efficiency. Multiply by3 then divide10:50→15J,150→45J. At input0 the proportional model givesW0; efficiency is given, not measured from0/0.

- **SIM-C3-L09-03**: eta_percent=W_J forQhot100J. Positive fixed100J input, output0..50J. Fractioneta=W/100, percent100eta; rejected heat100−W stays positive. Reference10J→10%,40J→40%. Do not confuse numeric percent with the fraction.

- **SIM-C3-L09-04**: eta_max_percent=100−T_cold/5. Carnot bound with Th500K,250<=Tc<=500K. Equality requires reversible operation; at equal temperatures bound0 is a degenerate no-positive-work limit. 250K→50%,400K→20%; use absolute temperatures, not Celsius differences or ratios.

- **SIM-C3-L10-01**: deltaS_body=Q_rev/300. Isothermal300K body exchanging reversible heat with signedQ into the body. This is not arbitrary irreversible heat divided byT; surroundings may compensate a negative body entropy change. Divide by300:−30→−.1J/K,60→.2J/K. PositiveQ andT do not fix a general irreversible path heat law.

- **SIM-C3-L10-02**: deltaS_total=Q/600. Ideal reservoirs600K and300K, heatQ>=0 from hot to cold, no other exchange. Energy conserved, entropyproductionQ(1/300−1/600). 30→.05J/K,90→.15J/K; sum signed reservoir changes, not their magnitudes.

- **SIM-C3-L10-03**: Omega(k)=binomial(4,k). Four distinguishable particles, exactly two locations each, integerk0..4. Compatible microstate counts1,4,6,4,1; equal probabilities are extra only when explaining frequencies. Choose whichk labels lie left; referencesk1→4,k2→6. No logarithm or factorial of a noninteger is physically permitted.

- **SIM-C3-L10-04**: deltaS_total_signed=Q/600. Sign convention hot-to-cold positive. NegativeQ would transfer heat cold-to-hot and reduce isolated total entropy, so it is a hypothetical forbidden spontaneous direction unless external intervention changes the model. −60→−.1J/K,30→.05J/K. Do not present negative-total-entropy controls as a naturally realized isolated process; actual consumer warning/direction must be read later.

