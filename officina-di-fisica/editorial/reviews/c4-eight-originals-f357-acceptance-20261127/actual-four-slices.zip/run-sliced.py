"""Run disjoint browser profiles with the existing visibility collector."""

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def load_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def section(full, number):
    profiles = full['profiles'][2 * number:2 * number + 2]
    include = {(str(profile['width']), profile['view']) for profile in profiles}
    keys = [key for key in full['expectedCaseKeys'] if tuple(key.split('|')[2:4]) in include]
    if len(profiles) != 2 or len(keys) != 112 or len(set(keys)) != len(keys):
        raise ValueError('Invalid two-profile slice of the frozen request')
    return {**full, 'profiles':profiles, 'expectedCaseKeys':keys}


def observe(app, collector, plan, attempt, env):
    out = attempt/'actual'
    write(attempt/'plan.json', plan)
    write(attempt/'browser-info.json', {'candidateApp':str(app), 'prepared':str(attempt/'plan.json'), 'output':str(out)})
    with open('/private/tmp/cric-bounded-local-work.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        free = shutil.disk_usage(attempt).free
        if free < 2 * 1024**3:
            write(attempt/'terminal.json', {'observedExitCode':None, 'reason':'Free disk below 2 GiB before child', 'freeBytes':free})
            raise ValueError('The immutable collector requires 2 GiB before the browser child')
        started = time.monotonic()
        timed = False
        with (attempt/'process.txt').open('x') as log:
            with subprocess.Popen(['node', str(collector), str(attempt/'browser-info.json')], cwd=app,
                                  env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True) as child:
                try:
                    code = child.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    timed = True
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        code = child.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        code = child.wait()
        write(attempt/'terminal.json', {'observedExitCode':code, 'timeoutTriggered':timed,
            'seconds':time.monotonic()-started, 'startingFreeBytes':free, 'activityCredit':0})
        if code or timed:
            raise ValueError('Preserved failed browser slice at ' + str(attempt))


def verify(attempt, plan, protocol_sha, validator, model):
    terminal = read(attempt/'terminal.json')
    plan_path = attempt/'plan.json'
    if terminal['observedExitCode'] != 0 or terminal['timeoutTriggered'] or read(plan_path) != plan:
        raise ValueError('Verified slice requires undisturbed exit and exact plan')
    out = attempt/'actual'
    report = validator.verify_report(out, plan, protocol_sha)
    if report['preparedSha256'] != sha(plan_path.read_bytes()) or report['errors']:
        raise ValueError('Observed slice plan or terminal evidence differs')
    interactions = validator.planned_interactions(plan)
    setups = states = 0
    for item in report['cases']:
        case = read(out/item['file'])
        row, state = interactions[item['caseKey']]
        validator.verify_planned_interaction(case, row, state)
        if state is None:
            if len(case['questions']) != 2 or not all(q['status'].startswith('Corretto. ') for q in case['questions']):
                raise ValueError('A real assigned submission failed in ' + item['caseKey'])
            setups += 1
        else:
            x = state['time'] if row['clockInput'] and 'time' in state else state['x']
            expected = model.value(row['id'], str(x), require_grid=state['kind']=='grid')
            if model.rational(str(case['model']['y'])) != expected:
                raise ValueError('An installed value differs from the independent rational model')
            states += 1
    if (setups, states) != (16, 96):
        raise ValueError('Actual browser coverage differs')
    return {'profiles':plan['profiles'], 'reportSha256':sha((out/'report.json').read_bytes()),
        'planSha256':sha(plan_path.read_bytes()), 'caseKeys':[row['caseKey'] for row in report['cases']],
        'actualSetupCases':setups, 'actualStates':states, 'actualAnsweredTasks':2*setups, 'activityCredit':0}


def main(app, numbers):
    provenance = read(ROOT/'preflight-origin.json')
    candidate = subprocess.check_output(['git','rev-parse','HEAD'], cwd=app, text=True).strip()
    if candidate != provenance['testedCandidateCommit']:
        raise ValueError('The candidate checkout moved')
    full = read(ROOT/'prepared448.json')
    preflight = read(ROOT/'actual-preflight-result.json')
    if preflight['preparedSha256'] != sha((ROOT/'prepared448.json').read_bytes()) or preflight['preparedUIKeys'] != 448:
        raise ValueError('The frozen full profile plan changed')
    collector = app/'tools/corpus_engineering/experiment_visibility_ui.mjs'
    protocol = sha(collector.read_bytes())
    if protocol != provenance['collectorSha256']:
        raise ValueError('The executed collector changed')
    env = {**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PATH':str(Path(sys.executable).parent)+os.pathsep+os.environ['PATH']}
    def fingerprint():
        return json.loads(subprocess.check_output([sys.executable,'-B','-m','tools.corpus_engineering.runtime_fingerprint'], cwd=app, env=env))
    if fingerprint() != full['runtimeFingerprint']:
        raise ValueError('The candidate runtime changed')
    validator = load_module(ROOT/'frozen-tools-corpus_engineering-experiment_visibility_request.py')
    model = load_module(ROOT/'independent_models.py')
    for number in numbers:
        directory = ROOT/f'profiles-{number}'
        directory.mkdir(exist_ok=True)
        plan = section(full, number)
        completed = directory/'completion.json'
        if completed.exists():
            saved = read(completed)
            actual = verify(directory/saved['attempt'], plan, protocol, validator, model)
            if actual != saved['result']:
                raise ValueError('A slice completion marker changed')
            continue
        attempt = directory/f'attempt-{len(list(directory.glob("attempt-*")))+1:02}'
        attempt.mkdir()
        observe(app, collector, plan, attempt, env)
        result = verify(attempt, plan, protocol, validator, model)
        if fingerprint() != full['runtimeFingerprint']:
            raise ValueError('Candidate runtime changed during a real browser slice')
        write(completed, {'attempt':attempt.name, 'result':result})
        print(json.dumps({'profiles':number,'cases':len(result['caseKeys']), 'setup':result['actualSetupCases']}),flush=True)
    results = [read(ROOT/f'profiles-{number}'/'completion.json')['result'] for number in range(4)
               if (ROOT/f'profiles-{number}'/'completion.json').exists()]
    if len(results) == 4:
        keys = [key for result in results for key in result['caseKeys']]
        if len(keys) != 448 or len(set(keys)) != 448 or set(keys) != set(full['expectedCaseKeys']):
            raise ValueError('Real slices do not cover the complete frozen request exactly once')
        aggregate = {'exactCandidateCommit':candidate, 'runtimeSha256':provenance['runtimeSha256'],
            'parentPlanSha256':preflight['preparedSha256'], 'collectorSha256':protocol, 'actualCases':len(keys),
            'actualAssignedAnswerEvents':sum(result['actualAnsweredTasks'] for result in results),
            'actualSlices':[result['reportSha256'] for result in results], 'manualImageReview':'PENDING',
            'humanApproval':'NOT_RUN', 'publicationAction':'NONE','activityCredit':0}
        output = ROOT/'sliced-terminal.json'
        if output.exists():
            if read(output) != aggregate:
                raise ValueError('The earlier full observation receipt changed')
        else:
            write(output, aggregate)
        print(json.dumps(aggregate),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('app', type=Path)
    parser.add_argument('profiles', nargs='*',type=int,choices=range(4))
    args = parser.parse_args()
    main(args.app.resolve(), args.profiles or range(4))
