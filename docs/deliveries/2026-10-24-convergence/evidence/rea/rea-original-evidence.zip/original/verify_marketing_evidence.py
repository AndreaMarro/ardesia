"""Independent oracle for the declared course-context and disclosure contract.

Reads retained REA evidence. Does not drive a browser or modify application state.
"""
import hashlib
import json
import pathlib
from html.parser import HTMLParser
from urllib.parse import parse_qs, urlsplit

ROOT = pathlib.Path(__file__).resolve().parent


class DocumentFacts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.open_details = set()
        self.media = []
        self.answer_controls = []

    def handle_starttag(self, tag, attributes):
        attributes = dict(attributes)
        if tag == 'details' and 'open' in attributes:
            self.open_details.update(attributes.get('class', '').split())
        if tag in ('audio', 'video'):
            self.media.append(tag)
        if tag in ('input', 'textarea', 'select', 'button'):
            self.answer_controls.append(tag)


def facts(step):
    document = DocumentFacts()
    document.feed(step['artifacts']['dom']['value']['text'])
    return document


def main():
    evidence = json.loads((ROOT / 'marketing-runtime-evidence.json').read_text())
    static = json.loads((ROOT / 'marketing-static-evidence.json').read_text())
    result = evidence['normalized_result']
    by_id = {step['step_id']: step for step in result['steps']}
    assertions = []

    def check(label, condition):
        assertions.append({'criterion': label, 'pass': bool(condition)})
        assert condition, label

    check('all eight declared actions completed', all(s['status'] == 'completed' for s in result['steps']) and len(result['steps']) == 9)
    check('complete capture in its declared scope', result['completeness']['status'] == 'complete')
    check('owned browser terminated', result['browser']['cleanup'] == 'terminated-owned-process')
    check('hint does not open the worked solution', facts(by_id['open-hint']).open_details == {'example-hint'})
    check('worked solution remains distinct from the error check', facts(by_id['open-reasoning']).open_details == {'example-hint', 'example-reasoning'})
    check('error explanation becomes visible on request', 'example-check' in facts(by_id['open-error-explanation']).open_details)
    destination = urlsplit(by_id['return-to-course']['after_url']['url'])
    check('return retains the canonical course id in URL and anchor', parse_qs(destination.query).get('percorso') == ['fluidi-termodinamica'] and destination.fragment == 'fluidi-termodinamica')
    check('course selection is actually restored in the DOM', by_id['selected-course-ready']['status'] == 'completed')
    requests = [event for event in result['events']['items'] if event['kind'] == 'request']
    expected_origin = by_id['ready']['after_url']['origin']
    check('all captured requests stayed on the local origin', all(event['url']['origin'] == expected_origin for event in requests))
    check('no captured page error', not any(event['kind'] == 'page-error' for event in result['events']['items']))
    check('preview is visibly an editorial draft', 'DRAFT' in by_id['open-original-example']['artifacts']['accessibility']['value']['text'])

    artifact_js = next((ROOT / 'marketing-artifact/assets').glob('site.*.js'))
    source_js = ROOT.parent.parent / 'ardesia/apps/marketing-01/assets/site.js'
    check('emitted script equals the canonical source byte-for-byte', artifact_js.read_bytes() == source_js.read_bytes())
    example_facts = facts(by_id['open-original-example'])
    conclusion = {
        'schema': 'ardesia.research.marketing-context-observation.v1',
        'target_commit': '339ab08f4139da0b37e78bbde81e9fe4e83afea0',
        'runtime_evidence_id': evidence['evidence_id'],
        'static_evidence_id': static['evidence_id'],
        'artifact_sha256': static['normalized_result']['root_artifact_sha256'],
        'source_js_sha256': hashlib.sha256(source_js.read_bytes()).hexdigest(),
        'assertions': assertions,
        'observed_scope_limits': {
            'audio_or_video_elements_in_example': example_facts.media,
            'answer_submission_controls_in_example': example_facts.answer_controls,
            'storage_at_end': by_id['selected-course-ready']['artifacts']['storage']['value'],
            'captured_request_methods': sorted({event['method'] for event in requests}),
            'graded_attempts_or_student_trace_verified': False,
            'lesson_audio_alignment_verified': False,
            'production_access_verified': False,
        },
        'interpretation': 'Course navigation and progressive disclosures work in this local mobile run. They do not establish a recorded lesson, grading, adaptation or persistent student memory.',
    }
    (ROOT / 'marketing-experiment-verification.json').write_text(json.dumps(conclusion, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': len(assertions), 'runtime_evidence_id': evidence['evidence_id'], 'scope': conclusion['observed_scope_limits']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
