"""Bounded local REA experiment; no contact links or production writes."""
import functools
import http.server
import json
import pathlib
import subprocess
import threading
import time

ROOT = pathlib.Path(__file__).resolve().parent
CLI = ROOT / 'toolchain/node_modules/rea-agents/scripts/rea.mjs'


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


def main():
    handler = functools.partial(QuietHandler, directory=str(ROOT / 'marketing-artifact'))
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    origin = f'http://127.0.0.1:{server.server_port}'
    actions = [
        {'step_id': 'ready', 'action': 'wait_for', 'locator': {'kind': 'css', 'selector': 'h1'}, 'state': 'visible'},
        {'step_id': 'select-fluid-course', 'action': 'click', 'locator': {'kind': 'css', 'selector': '.path-index a[href$="#fluidi-termodinamica"]'}},
        {'step_id': 'open-original-example', 'action': 'click', 'locator': {'kind': 'css', 'selector': '#fluidi-termodinamica .example-teaser'}},
        {'step_id': 'open-hint', 'action': 'click', 'locator': {'kind': 'css', 'selector': '.example-hint > summary'}},
        {'step_id': 'open-reasoning', 'action': 'click', 'locator': {'kind': 'css', 'selector': '.example-reasoning > summary'}},
        {'step_id': 'open-error-explanation', 'action': 'click', 'locator': {'kind': 'css', 'selector': '.example-check > summary'}},
        {'step_id': 'return-to-course', 'action': 'click', 'locator': {'kind': 'css', 'selector': '.example-back'}},
        {'step_id': 'selected-course-ready', 'action': 'wait_for', 'locator': {'kind': 'css', 'selector': 'input[name="course"][value="fluidi-termodinamica"]:checked'}, 'state': 'attached'},
    ]
    for action in actions:
        action['timeout_ms'] = 8000
    scenario = {
        'browser': {'mode': 'launch', 'executable_path': str(ROOT / 'browser-bin/chromium'), 'headless': True},
        'start_url': {'url': origin + '/'},
        'environment': {'viewport': {'width': 390, 'height': 844}, 'locale': 'it-IT', 'timezone': 'Europe/Rome', 'reduced_motion': 'reduce'},
        'actions': actions,
        'capture': {'after_each_step': ['url', 'dom', 'accessibility', 'storage'], 'at_end': ['url', 'screenshot', 'dom'], 'events': ['console', 'page-errors', 'network']},
    }
    for name in ('marketing-runtime-scenario.json', 'marketing-runtime-run.json', 'marketing-runtime-evidence.json', 'marketing-runtime-stderr.txt'):
        previous = ROOT / name
        if previous.exists():
            previous.rename(ROOT / name.replace('marketing-runtime', 'marketing-runtime-initial-failure'))
    (ROOT / 'marketing-runtime-scenario.json').write_text(json.dumps(scenario, indent=2))
    start = time.monotonic()
    try:
        with (ROOT / 'marketing-runtime-evidence.json').open('w') as out, (ROOT / 'marketing-runtime-stderr.txt').open('w') as err:
            result = subprocess.run(['node', str(CLI), 'capture-browser-scenario', str(ROOT / 'marketing-runtime-scenario.json'), '--format', 'json'], stdout=out, stderr=err, timeout=100)
        metadata = {'exit_code': result.returncode, 'elapsed_ms': round((time.monotonic() - start) * 1000), 'origin': origin, 'scope': 'local generated marketing preview; no external links activated'}
        (ROOT / 'marketing-runtime-run.json').write_text(json.dumps(metadata, indent=2))
        print(json.dumps(metadata))
        print((ROOT / 'marketing-runtime-stderr.txt').read_text()[-1000:])
    finally:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    main()
