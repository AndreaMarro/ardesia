// Narrow source query; intentionally not equivalent work to a REA artifact graph.
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const { parse } = require('./toolchain/node_modules/@babel/parser');
const target = path.join(__dirname, 'marketing-artifact/assets/site.084d55bb702f.js');
const source = fs.readFileSync(target, 'utf8');
const functions = [];
const start = performance.now();
const ast = parse(source, { sourceType: 'unambiguous' });
function visit(value) {
  if (!value || typeof value !== 'object') return;
  if (value.type === 'FunctionDeclaration' && ['choose', 'fromURL'].includes(value.id?.name)) {
    functions.push({ name: value.id.name, start: value.loc.start.line, end: value.loc.end.line });
  }
  for (const [key, child] of Object.entries(value)) {
    if (['loc', 'tokens', 'comments'].includes(key)) continue;
    if (Array.isArray(child)) child.forEach(visit);
    else if (child && typeof child === 'object') visit(child);
  }
}
visit(ast);
console.log(JSON.stringify({
  method: 'Direct Babel AST parse and query over same emitted JavaScript asset',
  elapsed_ms: Number((performance.now() - start).toFixed(3)),
  timing_scope: 'parse plus traversal; excludes Node startup, dependency load and file read',
  source_bytes: Buffer.byteLength(source),
  functions,
  comparability: 'Not equivalent to REA full artifact discovery, hashing and graph evidence',
}, null, 2));
