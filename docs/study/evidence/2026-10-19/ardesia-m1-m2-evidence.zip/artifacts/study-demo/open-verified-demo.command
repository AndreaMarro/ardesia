#!/bin/sh
cd 'REPO_ROOT'
exec 'REPO_ROOT/services/study-api/.venv/bin/python' bin/study-demo/serve.py --data-dir 'REPO_ROOT/.study-demo/run-2026-10-19T20-35-28-330Z' --port 5208
