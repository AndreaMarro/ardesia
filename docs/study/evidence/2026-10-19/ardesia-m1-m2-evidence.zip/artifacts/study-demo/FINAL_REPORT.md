# ARDESIA Fisica — consegna locale verificata

M0 e M1: PASS locale sintetico. M2: NOT_AUTHORIZED.

SHA `da0beb9430af05a8656b96b629082509a422fe51`; branch `codex/semestre-filtro-m1-20261019`. Albero pulito, nessun push/merge/deploy pubblico e consumo API prodotto 0 USD.

Studio 2154 pass/5 skip; Engine 2091 pass/7 skip; API 8 pass; gate frozen 2155 pass, 0 fail; 12 check hygiene con exit 0. Gli skip live/corpus/drift restano espliciti nei log.

La prova usa il build con SHA letto dal browser, dieci contesti distinti, consegne multimodali private, errori di rete, ricevuta recuperata dopo reload, tutor che modifica e pubblica la review, nuovo tentativo e LessonOS. Due persone restano in attesa, due interessi sono persistiti. Il riavvio cambia PID ([41369, 41584]) e riapre fonti/review/quaderno con profilo pulito. Backup paired verificato su DB e tre blob.

La review indipendente ha trovato due P1; riprodotte e corrette con regressioni RED/GREEN. Anche i due P2 materiali (risultato fisico obsoleto e lettore del quaderno) sono corretti e collaudati. Nessuna P0/P1 residua nel perimetro M1.

Il riepilogo macchina e gli hash sono in `final-receipt.json`; il run accettato è `run-2026-10-19T20-35-28-330Z`. Il bundle Git verificato richiede la base `b124eee0`; la patch è disponibile sullo stesso confronto. Avvio e limiti: `docs/study/README.md`. Per riaprire proprio la coorte verificata usare `open-verified-demo.command`; il servizio è già attivo esclusivamente su loopback :5208.

Restano NON ESEGUITI: modello/ASR/OCR live, pilot umano, review scientifica, pagamenti reali, Pencil/screen reader e CI remoto. Il notebook `.study.json` è in lettura e mostra le proprie omissioni; il formato canvas storico `.lesson` resta distinto. REA non era installato: documentato il fallback Playwright/sorgente e il livello DOC_ONLY delle fonti esterne.

L'automazione ogni 60 minuti continua a rileggere i quattro file e confrontare lavoro/prove; rimane silenziosa se invariati e riprende soltanto lavoro necessario nel perimetro autorizzato.
