# Revisione scientifica — DRAFT
Contenuto: relazioni-fluidi-v1 · SHA256: 3e0589e3647cc8d45e006c58839f2b83b06a13451f5d2985ac01eee8efaa321f

Sottoinsieme originale: conversioni geometriche, pressione, galleggiamento, proporzioni nel modello viscoso. Non copre l’intero syllabus o una simulazione ufficiale.

Reviewer umano: DA COMPILARE
Decisione: DA COMPILARE
Data/prova tutor: DA COMPILARE

Nessuna approvazione viene emessa da questo comando.

## Che cosa tieni fisso?
Q = π r⁴ Δp / (8ηL)
Moto laminare stazionario e sviluppato, fluido newtoniano incomprimibile, tubo cilindrico rigido. Modello non clinico.

## Cambiare unità senza cambiare oggetto
valore finale = valore iniziale × (scala iniziale / scala finale)^dimensione
Conversioni geometriche tra m, cm e mm per aree e volumi.

## Da quale pressione parti?
Δp = ρgh; p = p_superficie + ρgh
Liquido fermo incomprimibile, densità e g uniformi; h sotto la superficie.

## Quanto deve immergersi?
F_A = ρ_liquido g V_immerso; peso = ρ_corpo g V
Corpo omogeneo rigido libero da vincoli, liquido uniforme; trascurare aria e tensione superficiale.

### RF-01
Un tubo ideale passa da r₀ a 0.8 r₀. Δp, viscosità e lunghezza restano fissate. Quanto vale Q/Q₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Δp fissata si ottiene Q/Q₀ = 0.4096. Il rapporto è adimensionale.
Proposta numerica: 0.4096 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-02
Un tubo ideale passa da r₀ a 1.2 r₀. Δp, viscosità e lunghezza restano fissate. Quanto vale Q/Q₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Δp fissata si ottiene Q/Q₀ = 2.0736. Il rapporto è adimensionale.
Proposta numerica: 2.0736 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-03
Un tubo ideale passa da r₀ a 1.25 r₀. Q, viscosità e lunghezza restano fissate. Quanto vale Δp/Δp₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Q fissata si ottiene Δp/Δp₀ = 0.4096. Il rapporto è adimensionale.
Proposta numerica: 0.4096 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-04
Un tubo ideale passa da r₀ a 0.5 r₀. Q, viscosità e lunghezza restano fissate. Quanto vale Δp/Δp₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Q fissata si ottiene Δp/Δp₀ = 16. Il rapporto è adimensionale.
Proposta numerica: 16 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-05
Un tubo ideale passa da r₀ a 1.5 r₀. Δp, viscosità e lunghezza restano fissate. Quanto vale Q/Q₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Δp fissata si ottiene Q/Q₀ = 5.0625. Il rapporto è adimensionale.
Proposta numerica: 5.0625 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-06
Un tubo ideale passa da r₀ a 2 r₀. Δp, viscosità e lunghezza restano fissate. Quanto vale Q/Q₀? Dichiarare il regime richiesto.

Nel modello laminare il raggio compare alla quarta potenza. A Δp fissata si ottiene Q/Q₀ = 16. Il rapporto è adimensionale.
Proposta numerica: 16 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-07
Una misura geometrica vale 1.2 m². Esprimila in cm² senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 2. Risultato: 12000 cm². Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 12000 cm²
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-08
Una misura geometrica vale 720 cm². Esprimila in m² senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 2. Risultato: 0.072 m². Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 0.072 m²
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-09
Una misura geometrica vale 2e-06 m³. Esprimila in mm³ senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 3. Risultato: 2000 mm³. Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 2000 mm³
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-10
Una misura geometrica vale 1250 mm³. Esprimila in cm³ senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 3. Risultato: 1.25 cm³. Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 1.25 cm³
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-11
Una misura geometrica vale 320 cm³. Esprimila in m³ senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 3. Risultato: 0.00032 m³. Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 0.00032 m³
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-12
Una misura geometrica vale 84 mm². Esprimila in cm² senza cambiare la grandezza fisica.

Il fattore di conversione delle lunghezze va elevato a 2. Risultato: 0.84 cm². Cambia il numero con la sua unità, non l’oggetto.
Proposta numerica: 0.84 cm²
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-13
Liquido fermo: ρ=998 kg/m³, h=0.75 m, g=9.81 m/s², p alla superficie=100000 Pa. Calcola pressione assoluta.

Calcola prima Δp=ρgh. Aggiungi la pressione alla superficie. Risultato 107342.785 Pa.
Proposta numerica: 107342.785 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-14
Liquido fermo: ρ=800 kg/m³, h=1.2 m, g=10 m/s², p alla superficie=101325 Pa. Calcola incremento di pressione rispetto alla superficie.

Calcola prima Δp=ρgh. Non sommare la pressione alla superficie al solo incremento. Risultato 9600 Pa.
Proposta numerica: 9600 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-15
Liquido fermo: ρ=1000 kg/m³, h=0 m, g=9.81 m/s², p alla superficie=101000 Pa. Calcola pressione assoluta.

Calcola prima Δp=ρgh. Aggiungi la pressione alla superficie. Risultato 101000 Pa.
Proposta numerica: 101000 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-16
Liquido fermo: ρ=1200 kg/m³, h=0.5 m, g=9.8 m/s², p alla superficie=101325 Pa. Calcola incremento di pressione rispetto alla superficie.

Calcola prima Δp=ρgh. Non sommare la pressione alla superficie al solo incremento. Risultato 5880 Pa.
Proposta numerica: 5880 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-17
Liquido fermo: ρ=1000 kg/m³, h=3 m, g=9.81 m/s², p alla superficie=130000 Pa. Calcola pressione assoluta.

Calcola prima Δp=ρgh. Aggiungi la pressione alla superficie. Risultato 159430 Pa.
Proposta numerica: 159430 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-18
Liquido fermo: ρ=1020 kg/m³, h=2.5 m, g=9.8 m/s², p alla superficie=101325 Pa. Calcola incremento di pressione rispetto alla superficie.

Calcola prima Δp=ρgh. Non sommare la pressione alla superficie al solo incremento. Risultato 24990 Pa.
Proposta numerica: 24990 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-19
Corpo omogeneo libero: ρ corpo=600 kg/m³, volume=0.001 m³; liquido ρ=1000 kg/m³; g=9.81 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 9.81 N. Il peso si equilibra con frazione immersa 0.6; la spinta effettiva al galleggiamento è il peso, inferiore alla spinta massima.
Proposta numerica: 9.81 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-20
Corpo omogeneo libero: ρ corpo=1000 kg/m³, volume=0.002 m³; liquido ρ=800 kg/m³; g=10 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 16 N. Peso maggiore della spinta massima: il corpo affonda, nessuna frazione di equilibrio ≤1.
Proposta numerica: 16 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-21
Corpo omogeneo libero: ρ corpo=1200 kg/m³, volume=0.0005 m³; liquido ρ=1200 kg/m³; g=9.8 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 5.88 N. Densità uguali: equilibrio indifferente completamente immerso.
Proposta numerica: 5.88 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-22
Corpo omogeneo libero: ρ corpo=200 kg/m³, volume=0.003 m³; liquido ρ=1000 kg/m³; g=10 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 30 N. Il peso si equilibra con frazione immersa 0.2; la spinta effettiva al galleggiamento è il peso, inferiore alla spinta massima.
Proposta numerica: 30 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-23
Corpo omogeneo libero: ρ corpo=450 kg/m³, volume=0.004 m³; liquido ρ=900 kg/m³; g=9.81 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 35.316 N. Il peso si equilibra con frazione immersa 0.5; la spinta effettiva al galleggiamento è il peso, inferiore alla spinta massima.
Proposta numerica: 35.316 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### RF-24
Corpo omogeneo libero: ρ corpo=1300 kg/m³, volume=0.0015 m³; liquido ρ=1100 kg/m³; g=9.8 m/s². Calcola la spinta massima a immersione completa. Può restare in equilibrio libero? Se galleggia, quale frazione è immersa?

La spinta massima è ρ liquido × g × V = 16.17 N. Peso maggiore della spinta massima: il corpo affonda, nessuna frazione di equilibrio ≤1.
Proposta numerica: 16.17 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-A1
Una finestra ha area 4,3 cm². Quanti mm²? Spiega perché non basta moltiplicare per 10.


Proposta numerica: 430 mm²
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-A2
Liquido ρ=980 kg/m³; profondità 1,8 m; g=10 m/s². Quanto aumenta la pressione rispetto alla superficie?


Proposta numerica: 17640 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-A3
Una pompa mantiene Q. Il raggio aumenta del 10%, η e L fissate. Rapporto delle differenze di pressione? Dichiarare il dominio.


Proposta numerica: 0.6830134553650706 1
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-B1
Un volume di 1250000 mm³ deve essere riportato in m³. Quale fattore usi?


Proposta numerica: 0.00125 m³
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-B2
ρ=1250 kg/m³, h=0,4 m, g=9,81 m/s², pressione superficiale 99000 Pa. Qual è la pressione assoluta?


Proposta numerica: 103905 Pa
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________

### TR-B3
Corpo omogeneo ρ=680 kg/m³, V=0,006 m³ in liquido ρ=850 kg/m³, g=10 m/s². Spinta massima e frazione di equilibrio?


Proposta numerica: 51 N
Ipotesi, unità, soluzione, accessibilità, originalità: [ ] da verificare
Decisione/commento umano: ____________________
