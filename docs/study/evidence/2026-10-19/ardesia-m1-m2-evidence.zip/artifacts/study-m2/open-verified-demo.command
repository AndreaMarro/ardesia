#!/bin/zsh
set -e
cd 'REPO_ROOT'
if [[ ! -f artifacts/study-m2/final-receipt.json ]]; then
  print 'Final verification receipt not present.'
  exit 1
fi
open 'http://127.0.0.1:5208/?vista=fisica'
