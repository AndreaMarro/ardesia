# ARDESIA — preparazione locale verso M2

Stato: **piano locale completato, gate umani aperti**. Commit `d966863eba06a735ad01e1da1211033642a5bc98`, checkout pulito. Nessun merge, deploy pubblico, pagamento o nuovo consumo API. Solo utenti sintetici.

- Inviti monouso, revoca sessioni, limiti HTTP e cookie HTTPS provati localmente. Avvio di produzione ancora rifiutato.
- Backup v2 verificato, restore in nuova directory, riavvio HTTP con originali e memoria; cancellazione di uno studente soltanto su copia sintetica e replay su un backup precedente. Restano nove membri e due blob, senza ripristinare lo studente cancellato.
- 24 esercizi originali DRAFT, quattro modelli manipolabili, due prove di trasferimento con sei nuovi quesiti, soluzioni proposte, rubriche e packet di revisione con SHA256 `3e0589e3647cc8d45e006c58839f2b83b06a13451f5d2985ac01eee8efaa321f`. Nessuna firma scientifica umana.
- Una review indipendente ha individuato quattro difetti materiali: riprodotti e corretti. Correzione aggiuntiva dell’autore per note Unicode e budget del quaderno. Le correzioni hanno prove RED/GREEN e suite finali; nessuna seconda review indipendente è rivendicata.

Verifica su questo SHA: Studio **2155 pass/5 skip**, Engine **2114 pass/7 skip**, API **12 pass**; typecheck/build, 12 controlli hygiene, tre scenari browser e ripristino a freddo passati. Gate Studio: `{"passed": 2156, "failed": 0, "exit": 0}`. Gli skip live/corpus/sibling Engine sono nei log; nessuna chiave provider abilitata. Rimane il warning di deprecazione TestClient/httpx.

La demo è servita da `http://127.0.0.1:5208/?vista=fisica`, processo 52359, dati `REPO_ROOT/.study-demo/run-2026-10-19T21-21-03-225Z`. Per riavviare dalla root usare:

```sh
services/study-api/.venv/bin/python bin/study-demo/serve.py --no-seed --data-dir 'REPO_ROOT/.study-demo/run-2026-10-19T21-21-03-225Z' --port 5208
```

Gli accessi privati sono in `REPO_ROOT/.study-demo/run-2026-10-19T21-21-03-225Z/demo-access.json`: usare tutor-synthetic o student-02; l’accesso seed student-01 è stato revocato intenzionalmente dal test e il tutor può creare un nuovo invito. Non distribuirli. Il bundle Git verificato `ardesia-semestre-m2.bundle` richiede il commit base `b124eee04acc8062c27284f23c5d9108e3767c27`; patch e bundle non includono directory runtime o credenziali.

Per la revisione umana: `run-2026-10-19T21-21-02-985Z/content-review/review-worksheet.md`, con hash/JSON accanto; runbook e scheda owner in `docs/study/m2-runbook.md` e `docs/study/m2-human-kit.md`. I modelli/ID RF/TR sono anteprime editoriali: consegne/review attuali in Lezione tracciano poiseuille-v1. Prima del pilot servono decisioni scientifiche, prova personale tutor, trattamento/diritti/conservazione, calendario/condizioni/supporto, accessibilità reale e collaudo dell’infrastruttura scelta. `check-readiness.py` termina correttamente con exit 2 e launchAllowed=false.

Il riesame dei quattro file ogni 60 minuti resta attivo. File invariati al controllo corrente; la richiesta diretta dell’utente, distinta dal dossier, autorizza la preparazione locale verso M2. La ricevuta M1 storica non è stata sovrascritta. Le prove definitive sono `final-receipt.json`, `final-checks/` e il manifest del run indicato; i run precedenti, l’errore d’invocazione del test live e il gate interrotto sono conservati come evidenza di lavoro e non costituiscono la verifica finale.
