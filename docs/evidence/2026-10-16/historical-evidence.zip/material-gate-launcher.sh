#!/bin/bash
# Environment adapter only: execute the unchanged project gate and real locked tools.
# Records completion even if the desktop loses the command-session handle.
set -uo pipefail
export ARDESIA_TASK_NODE=/Users/andreamarro/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
export ARDESIA_TASK_STUDIO=/private/tmp/codex-ardesia-close-20261016/apps/studio
export ARDESIA_TASK_CALLS=/private/tmp/ardesia-frozen-gate-1a71d913-tool-calls.log
export NODE_OPTIONS=--no-experimental-webstorage
unset OPENAI_API_KEY KIMI_API_KEY DEEPSEEK_API_KEY SKIP_REPLAY

npx() {
  local selected="$1"
  shift
  local script
  case "$selected" in
    tsc) script="$ARDESIA_TASK_STUDIO/node_modules/typescript/bin/tsc" ;;
    vitest) script="$ARDESIA_TASK_STUDIO/node_modules/vitest/vitest.mjs" ;;
    vite) script="$ARDESIA_TASK_STUDIO/node_modules/vite/bin/vite.js" ;;
    playwright) script="$ARDESIA_TASK_STUDIO/node_modules/@playwright/test/cli.js" ;;
    *) printf 'Unsupported gate tool: %s\n' "$selected" >&2; return 127 ;;
  esac
  if [ "$selected" = vitest ]; then
    # Same deterministic runner flags required by apps/studio/AGENTS.md.
    set -- "$@" --pool=threads --maxWorkers=1 --no-file-parallelism --testTimeout=30000 --hookTimeout=30000 --teardownTimeout=30000
  fi
  printf '%s' "$selected" >> "$ARDESIA_TASK_CALLS"
  printf ' %q' "$@" >> "$ARDESIA_TASK_CALLS"
  printf '\n' >> "$ARDESIA_TASK_CALLS"
  "$ARDESIA_TASK_NODE" "$script" "$@"
}
export -f npx
cd "$ARDESIA_TASK_STUDIO" || exit 1
if [ "$(git rev-parse HEAD)" != 1a71d91379ea954ee54a1955b05d22e50401e535 ] || [ -n "$(git status --porcelain)" ]; then
  printf 'Source checkpoint is not the clean frozen candidate\n' >&2
  exit 1
fi
bash eval/gate.sh
gate_rc=$?
printf '{"exitCode":%s,"head":"1a71d91379ea954ee54a1955b05d22e50401e535"}\n' "$gate_rc" > /private/tmp/ardesia-frozen-gate-1a71d913-completion.json
exit "$gate_rc"
