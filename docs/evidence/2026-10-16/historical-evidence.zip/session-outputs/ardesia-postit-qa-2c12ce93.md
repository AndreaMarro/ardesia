# Post-it — prova circoscritta di riapertura

Base `b124eee04acc8062c27284f23c5d9108e3767c27`, candidato `2c12ce93e76793ec32f8a390ee247bd989effc1c`, tree `eb366049f96be12e35aa25c3e2ddeb207bbfc8ff`, branch `codex/postit-reload-20261016`. READY_FOR_REVIEW locale; non pushed, senza PR/CI, non integrato. Recupero minimo da4237f19: un link presente contraddittorio viene rifiutato; null/assente e legacy restano compatibili.

Sul candidato esatto: **6browserPASS,0FAIL,0SKIP,exit0,19,8s**, worker1/retry0, Chromium148.0.7778.96/Playwright1.60.0/Node24.19.0. Identità runtime letta da `window.__ARDESIA_BUILD__`. Due casi esistenti import/render; due nuovi su desktop1440×960 e tablet768×1024 attraversano gesto reale (bordo+freccia), conferma contenuto scritto, reload, export API, import UI in un contesto vuoto e secondo reload. Identità, owner, link, stato, geometria e consumer di sim-a preservati. Nessun errore console/pageerror/overlay. Due casi iniettano scritture scena negate: errore visibile e precedente posizione salvata riaperta.

I due mutanti sono rilevati all'assert previsto dopo reload: storage cancellato→zero card invece di tre; renderer costante→0 invece di0,0153. Nessun crash generico o mutante invalido. Helper conservati fuori dalla discovery normale.

Il bundle allegato è prodotto dall'API reale e dichiara il commit del candidato nel manifest. Contiene board, journal e sessione; non contiene snapshot LessonOS, audio o PDF. I valori iniziali dei post-it sono fixture sintetiche: non una prova scientifica del solver.

![Riapertura desktop](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-riaperti-desktop-2c12ce93.png)

![Panoramica tablet](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-riaperti-tablet-2c12ce93.png)

Schermate ispezionate: identità e consumer sono presenti. Sul tablet lo zoom-to-fit reale porta il canvas al50%: questa è una panoramica; leggere ogni card richiede zoom/pan. Non accessibilità completa. La visualizzazione preesistente di0 con provider indisponibile rimane un difetto distinto, non avallato da questa prova.

6RED autentici link,22miratiPASS, full2158PASS5SKIP esterni, tipi/buildPASS,13LocalChecks fastPASS. Frozen gate invariato sul candidato2159PASS0FAILexit0, incluso replay, Node26.5.1. Review separata favorevole e22mirati indipendentiPASS; non approval umana GitHub. Setup iniziali conservati: path test/symlink errato; due browserFAIL solo da font403 della dipendenza fuori root, risolti con npmci locked locale senza filtro console o modifica Vite. Nessun gate/skip/retry/timeout cambiato.

[Bundle esportato](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-esportati-2c12ce93.lesson), [identità prima/dopo](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-identita-ui-2c12ce93.json), [patch applicabile alla base](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-identita-2c12ce93.patch), [prove e hash](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-postit-prove-2c12ce93.json). PR262 resta alla review umana. Nessuna prova integrata completa Ardesia/Kirchhoff, pilot, riavvio processo o durabilità fisica.
