# LED e corrente: prove del candidato locale8c5d650a

Su base `b124eee04acc8062c27284f23c5d9108e3767c27`, branch `codex/led-unknown-20261016`, candidato `8c5d650ae59659357a0d0f46c7306287634158aa`, tree `255575f80cdb0c18cc5e69e9cc616e32706ebf1c`. Nessun push/PR/CI: main resta invariato.

Un risultato assente o rifiutato mostra `?`, mentre uno zero misurato rimane zero. RGB incompleto e numeri nonfiniti non producono misure inventate. Il Lab condivide stato mono validato fra pannello e canvas. Embed mono e metriche leggono la disponibilità del solve; un campo assente non prende il LOW iniziale Arduino.

| Verifica | Esito |
|---|---|
| Suite Studio, flag deterministici prescritti |2185PASS5SKIP, exit0,113.92s|
| Typecheck / build / LocalChecks fast |exit0 / exit0 /13PASS|
| Gate invariato suSHA esatto |2186PASS0FAIL, exit0; incluso replay|
| Browser nativo, retry0, worker1 |19PASS0SKIP, exit0, durata riportata1.0m|
| Controreview separata |4controprove invariatePASS; nessun blocker residuo nel perimetro|
| Patch su base pulita |git apply --check, exit0|

I cinque skip richiedono screenshot esterne assenti e restano invariati. La prima review461 era WITH FIXES: i tre rilievi sono stati riprodotti e corretti; conservati anche gli errori di setup e i clic intercettati.

I tre bundle [valido](ardesia-led-healthy-8c5d650a.lesson), [corto](ardesia-led-short-8c5d650a.lesson), [aperto](ardesia-led-open-8c5d650a.lesson) vengono dall'API reale di export con event log IndexedDB; import UI e reload in un destinatario nuovo vuoto conservano l'esito. Contengono manifest, scena, journal, sessione e snapshot canonico; non audio o PDF. [Eventi e digesti](ardesia-led-trasporto-8c5d650a.json) mostrano risultato→errore per il corto e risultato→zero per l'aperto. Le duplicazioni dopo reload sono osservate, senza claim di deduplica globale.

[Desktop dopo riapertura](ardesia-led-corto-riaperto-8c5d650a.png): errore e stato RGB non disponibile leggibili; circuito parzialmente tagliato. [Mobile Workbench](ardesia-led-ignoto-mobile-8c5d650a.png): diagnostica e `?mA` leggibili. [Lab](ardesia-led-lab-coerente-8c5d650a.png): pannello acceso15.3mA e glow del LED concordano; sidebar sovrapposta a parte del circuito. Immagini ispezionate sul candidato esatto.

Limiti:12casi recuperati includono harness/seed sintetici; il reset in memoria non è durabilità. I nuovi casi fanno trasferimento realeRGB3, Lab2, import/reload mono2. Export API non equivale a test del flusso completo di export UI. Due contesti non provano riavvio processo, perdita alimentazione o collaborazione remota. Il mobile embed usa una panoramica con zoom-to-fit. Nessuna attestazione generale di accessibilità, penna, kernel o freshness asincrona. Append/chiusura/materiale e percorso completo restano da verificare.

[Patch](ardesia-led-ignoto-8c5d650a.patch) · [Prove e hash](ardesia-led-prove-8c5d650a.json). PR262 richiede review umana GitHub; questa review tecnica non la sostituisce. Nessuna richiesta provider osservata nell'unità LED; resta registrato l'incidente precedente dell'unità atomica, con costo ignoto.
