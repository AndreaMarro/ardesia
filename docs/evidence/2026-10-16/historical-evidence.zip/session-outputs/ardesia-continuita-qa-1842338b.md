# Continuità — verifica UI del candidato 1842338b

Base `b124eee04acc8062c27284f23c5d9108e3767c27`, candidato `1842338b0f71693c2c42ad4ed061b972c9e2cd96`, tree `05256bbd9bfdce9c70677a8ea3da2a5f149a736b`, branch `codex/continuity-storage-20261016`. Stato READY_FOR_REVIEW locale; non pushed, senza PR/CI, main invariato. PR262 richiede ancora una review umana.

La schermata conserva il descrittore del backend prima di leggere l'indice: un archivio danneggiato o parziale non diventa un elenco vuoto o apparentemente verificato. Nessuna riparazione o scrittura introdotta. Riutilizzati componenti e navigazione esistenti.

Browser reale Chromium148.0.7778.96, Playwright1.60.0, Node24.19.0, server locale5198 con `window.__ARDESIA_BUILD__.commitSha` uguale al candidato. **12PASS,0FAIL,0SKIP,exit0,36,0s**, worker1/retry0. Sei casi su1440×900 e390×844: gap senza chiavi, V2 malformato, legacy non attribuito, gap con chiavi ancora presenti, vuoto verificato, sessione verificata.

Ogni contesto nasce vuoto. Le fixture innocue vengono inserite soltanto nel suo IndexedDB nativo; vengono verificati classificazione dell'adattatore reale, reload, pagina nuova nello stesso contesto, schermata reale e uguaglianza delle righe dopo la lettura. Titolo/URL corretti, zero errori console/pageerror o overlay Vite, nessun overflow orizzontale. Focus e Invio su Materiali funzionano. Screenshot desktop danneggiato e mobile parziale ispezionati: testo e navigazione leggibili, nessun taglio o sovrapposizione osservato.

![Archivio danneggiato desktop](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-archivio-danneggiato-1842338b.png)

![Archivio parziale mobile](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-archivio-parziale-mobile-1842338b.png)

Prima del codice: browser8FAIL4PASS; consumer/view4FAIL e nav2FAIL autentici. Il precedente errore di avvio Chromium non era una riproduzione funzionale. Dopo:25test miratiPASS; full2155PASS5SKIP (suite screenshot esterna assente); tipi/buildPASS;13LocalChecks fastPASS; gate frozen invariato su SHA finale2156PASS0FAILexit0, compreso replay. Gate con Node26.5.1 scelto dal suo PATH. Review separata favorevole sullo SHA esatto,25+12mirati e controprove; non review umana GitHub.

Questa prova non attesta byte fisici del database, riavvio completo del browser, recupero dei dati, durabilità generale, accessibilità completa, collaborazione o percorso integrato con Kirchhoff. Nessun provider invocato osservato in questa unità; l'incidente precedente resta nel resoconto generale.

[Patch](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-continuita-storage-1842338b.patch) applicabile alla base con `git apply --check` exit0. [Prove, comandi, SHA, hash e limiti](/Users/andreamarro/Documents/Codex/2026-10-16/es/outputs/ardesia-continuita-prove-1842338b.json).
