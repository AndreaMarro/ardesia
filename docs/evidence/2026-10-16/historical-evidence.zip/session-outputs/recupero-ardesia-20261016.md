# Recupero Ardesia — stato al16ottobre2026

Main `b124eee04acc8062c27284f23c5d9108e3767c27` invariato; archivio `5b1f65779701ba680a9b4d7d0841dc9c021422ff`. Recupero selettivo, nessuna fusione della mega-PR. Una sola PR di consegna attiva: [reader262](https://github.com/AndreaMarro/ardesia/pull/262), headb9bff962, OPEN/non-draft, tutti i checkSUCCESS ma mergeBLOCKED/REVIEW_REQUIRED.

| Requisito | Provenienza e capacità | Prova discriminante | Stato / prossimo passo |
|---|---|---|---|
| Budget generale .lesson prima degli effetti | reader +#248 selettivi; limiti archivio/central directory/membri/testi/totale/byte effettivi, PDF anticipati, hashing a blocchi |97miratiPASS; ZIP reali con metadata mendaci; nessun effetto store/router sui rifiuti provati | PR262b9; merge richiede review umana |
| Manifest e journal moderno |#248/bundle_extensions; schemi1/2/3, inventario/hash, legacy/v2 selezionato; snapshot opaco distinto da validità semantica |locale2109PASS7SKIP; CIengine2107PASS9SKIP/Studio2149PASS5SKIP;35controprove reviewPASS | PR262, non integrata |
| Re-ingest coerente |#253/tag; staging e pubblicazione atomica di segmenti/capsula con schemaSQLite11/CAS |42casi nuovi; DBsu file, connessioni/processi/crash;2151PASS7SKIP offline;review favorevole | Locale6536991c su readerb9; non pushed/PR/CI/integrato |
| Storage: errore distinto da vuoto |9800fe6/5aa0740 selettivi; corrupt/data-loss conservati prima della query, UI danneggiato/parziale |REDbrowser8FAIL4PASS;25miratiPASS;2155PASS5SKIP;frozen2156PASS;12browserPASS su IndexedDB nativo | Locale1842338b su mainb124;review favorevole; non integrato |
| Identità post-it dopo reload |4237f19/#244; link presente coerente, identità/valori/link dopo gesto e scrittura reali |22miratiPASS;2158PASS5SKIP;frozen2159PASS;6browserPASS;2guasti scrittura visibili;2mutanti uccisi | Locale2c12ce93 su mainb124;review favorevole; non integrato |
| LED/corrente ignoti distinti daOFF/zero |#243,d0ec9303/89192106/a47cd69d selettivi; consumer mono/RGB, canvas Lab, export eventi/digesto |2185PASS5SKIP;frozen2186PASS;19browserPASS;4controprove reviewPASS;3bundle produttore esatto | Locale8c5d650a su mainb124;review favorevole; non integrato |
| Chiusura/materiale alla medesima revisione |#258headf155d37 non antenato del checkpoint; verificare primitive già esistenti |lostACK,retry/dedup,watermark,ultimo append accettato e snapshot/materiale coerenti | Prossima unica unità primaria: DA SELEZIONARE |

Il primo readerf9b5722 fu respinto: P1sceltaEOCD diversa daZipFile e P2file_size mendace che troncava la lettura;3RED veri, correzioni e35controprove su b9. Gli skip engine includono provider live/dipendenze o corpus esterni assenti; CIaggiunge2skip Linux case/NFD. I5skipStudio dipendono dalle screenshot esterne maestro-logs/ui-shots assenti. Nessun gate/skip/retry/timeout indebolito.

La prima review LED461 ha richiesto fix: disponibilità omessa nell'embed mono, Lab raw on-only/NaN, e campo assente trasformato in ArduinoLOW.4controprove RED permanenti, poi4PASS indipendenti sul candidato8c5. I candidati locali sono separati, non un main composito già verificato. [Prove LED](ardesia-led-prove-8c5d650a.json), [QA](ardesia-led-qa-8c5d650a.md).

Incidente atomico preservato: un run con chiavi ereditate ha attivato4testlive,2153PASS2FAIL3SKIP (2HTTP404Kimi), richieste esterne involontarie/costo ignoto; l'offline verde non cancella quel FAIL. Nelle unità Studio successive le3chiavi sono escluse. Pipeline narrativa LLM/policyZERO-LLM ancora in collisione: nessuna promozione di quel percorso. Anteprime GitHub/Vercel automatiche già registrate; nessun comando di deploy esplicito.

Percorso completo a due revisioni e pilot umano ancora NONRUN. [Indice operativo](resoconto-esecuzione-20261016.md) e [manifest](integrazione-baseline-20261016.json).
