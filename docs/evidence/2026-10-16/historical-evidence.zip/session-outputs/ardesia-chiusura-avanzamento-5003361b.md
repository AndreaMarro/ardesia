# Ardesia — chiusura e materiale: avanzamento locale

**IN CORSO.** Checkpoint `5003361b7e3dc17352aec991f157152c52c3ce4d`, tree `a7df755b3ddba0d735777ee69d7834069833f47b`, su main `b124eee04acc8062c27284f23c5d9108e3767c27`. Il percorso completo lezione → memoria → materiale della stessa revisione resta da completare. Nessun push, nuova PR, merge o deploy in questo avanzamento.

Le azioni accettate vengono drenate prima della fine lezione. Ritardo, rifiuto e ACK perso producono attesa o errore visibile e retry deliberato, conservando l'identità dell'evento. Se la fine potrebbe essere già salvata, il canvas resta congelato fino al recupero. La review del predecessore ha trovato due difetti reali: riapertura del canvas dopo timeout dell'ACK di fine e capability clone che tratteneva un vecchio renderer. Tre controprove permanenti hanno guidato le correzioni. La controreview `3ac3574e` ha concluso senza nuovi rilievi concreti nel perimetro, con 34 verifiche indipendenti passate.

L'export Materiali acquisisce l'archivio persistente fresco per ogni clic. Un errore non diventa un export falsamente vuoto e un log corrente vuoto non ripristina silenziosamente lo snapshot precedente. La compatibilità con archivi legacy rimane esplicita. Il riepilogo ora legge prima il journal della lezione, conserva testo finale e provenienza, distingue pagine PDF importate da pagine osservate e non inventa un titolo di manuale o una fonte verificata.

| Checkpoint | Verifica conclusa |
|---|---|
| `3ac3574e` | 2.188 PASS, 5 skip preesistenti; tipi e build PASS; review indipendente 34 PASS |
| `3ac3574e` | 6 browser PASS su desktop1440 e mobile390, ritardo/rifiuto/ACK perso; domanda digitata, Simulation reale, export UI .lesson |
| `5003361b` | 2.198 PASS, 5 skip preesistenti, 82,22 s; tipi e build PASS; 185 consumer mirati PASS |
| `5003361b` | 4 test della nuova esclusione di lettura e 6 test del journal canonico prima RED; nuovi meccanismi ancora da collegare alla cattura del materiale |

I sei export browser riportano il producer `3ac3574e` nel manifest, negli eventi e nel journal. Il [bundle dell'ACK perso](ardesia-chiusura-ack-perso-3ac3574e.lesson) e la [schermata mobile](ardesia-chiusura-ui-mobile-3ac3574e.png) sono prove di quel predecessore. I dati raw del test conservano l'etichetta prudenziale draft; il binding al commit effettivo è verificato separatamente nelle [prove](ardesia-chiusura-prove-5003361b.json). Nessuna prova browser sul checkpoint successivo `5003361b` è dichiarata.

Il nuovo lock di lettura tiene chiusa una lezione durante una callback di cattura: due autori attivi impediscono la lettura; nuove aperture e mutazioni attendono il rilascio. I test attuali usano il broker avversario esistente: la prova nativa fra due schede resta da eseguire. Nei browser con esclusione solo locale la lettura non può attestare la coerenza fra schede.

Restano: cattura unica sotto tale lock, proiezione canonica del digest per sessione, collegamento della schermata read-only senza trattenere la propria attività Room, riuso degli stessi byte per anteprima e download, prova reale materiale/PDF e destinatario riaperto. Gate frozen finale e review dell'intera unità rimangono pendenti. Il checkpoint `5003361b` è in review tecnica separata. Integrazione Ardesia e pilot umano non sono stati eseguiti. La PR262 resta OPEN con check SUCCESS e review umana richiesta da GitHub.

Nessuna soglia, protezione, schema persistito, solver o gate è stato indebolito. Le tre chiavi provider erano escluse e non sono state osservate richieste provider in questo avanzamento. L'incidente precedente dell'unità atomica, con richieste involontarie e costo ignoto, resta documentato. Errori di setup e risultati intermedi sono conservati separatamente; i run verdi non li cancellano.


Aggiornamento successivo — review WITH_FIXES: import-only e regressione legacy successiva sono riprodotti e corretti. Questo documento resta storico. [Avanzamento corrente](ardesia-chiusura-avanzamento-bf47eb4e.md).
