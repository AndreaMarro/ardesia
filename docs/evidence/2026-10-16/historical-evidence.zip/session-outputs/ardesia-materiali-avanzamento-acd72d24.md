# Ardesia — cattura del materiale della lezione chiusa

**Stato: IN_PROGRESS, codice locale.** Commit `acd72d24ef32090d599987e1c74c1f5c204b4e54`, base `b124eee04acc8062c27284f23c5d9108e3767c27`. Nessun push, nuova PR, merge o deploy di questa unità.

Il riepilogo acquisisce una sola revisione inattiva: anteprima HTML e download usano gli stessi dati catturati. L’evento finale conserva una ricevuta dei byte del workspace; ciascuna riga degli appunti deve essere inclusa nel prefisso attestato dalla propria sessione. Il titolo sopravvive al trasferimento, anche per identificatori di lezione con lettere maiuscole. I riferimenti e gli ID restano quelli registrati; corrente assente e zero rimangono distinti. Gli hash verificano coerenza, non autenticità o correttezza scientifica.

La route del riepilogo evita di aprire una Room che bloccherebbe la lettura inattiva. Errori, cambio stanza e aggiornamento non conservano un vecchio materiale come risultato corrente.

| Verifica | Esito reale |
| --- | --- |
| TypeScript del nuovo codice | PASS |
| Revisione indipendente sul commit attuale | 12 PASS; entrambi i rilievi P2 precedenti risolti |
| Esecuzione mirata del coordinatore | 62 PASS in sei file; esecuzione complessiva FALLITA perché il worker Room non è partito |
| Suite completa sul commit attuale | FALLITA: 2.202 PASS, due asserzioni fallite, cinque skip e otto errori di avvio worker; 4.590,21 s |
| Build e nuova prova browser sul commit attuale | NON ANCORA ESEGUITE |
| Checkpoint precedente e6c5bbd5 | 2.243 PASS, cinque skip preesistenti; build PASS; aveva i due P2 poi corretti |

La macchina ha mostrato carico elevato e circa 19 GB di swap occupati. Tutti i fallimenti restano conservati nelle evidenze; timeout e gate non sono stati modificati. Le due asserzioni riguardano il primo evento Simulation nei test di cambio generazione e persistenza: causa ancora in diagnosi. Un successivo controllo mirato non ha eseguito test perché il worker non è partito; non costituisce né conferma né smentita delle due asserzioni.

**Resta lavoro necessario:** prova nel browser con due schede e destinatario isolato, figure nel materiale umano, formule/PDF verificati, composizione dei candidati locali e verticale completo fra i due prodotti con pilot umano. L’HTML segnala esplicitamente che le figure sono conservate nel `.lesson` ma non incluse nell’anteprima: il requisito del materiale completo non è soddisfatto.

La [PR 262](https://github.com/AndreaMarro/ardesia/pull/262), ricontrollata in questa sessione, è OPEN/BLOCKED con REVIEW_REQUIRED e controlli verdi. Richiede ancora review umana; questa revisione tecnica locale non la sostituisce.

[Patch cumulativa locale](ardesia-materiali-acd72d24.patch) · [Stato e hash delle evidenze](ardesia-materiali-prove-acd72d24.json). I precedenti output restano storici e separati; questo documento non attesta integrazione su main.

Aggiornamento: build Vite esatta acd PASS (25,83s; warning chunk preesistente). Il successore locale `14f68791` aggiunge solo barriere React `act` alla fixture Room: 108/108 PASS, oracoli e timeout invariati, review del delta senza finding. Il primo tentativo limitato dopo la sola barriera addSource resta 1PASS/1FAIL alla readiness; non è stato cancellato. Il full sul successore è in corso, nessuna prova nativa ancora eseguita. La causa storica delle due asserzioni del full acd non è certificata.
