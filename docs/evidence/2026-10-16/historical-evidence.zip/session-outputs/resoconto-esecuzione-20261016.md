# Esecuzione Kirchhoff / Ardesia — stato al16ottobre2026

Tre unità Kirchhoff sono integrate (PR25/26/27). Ardesia ha un reader con CI verde in PR262 e quattro candidati locali revisionati; richiede ancora la review umana GitHub per il merge. Il percorso completo fra i due prodotti e il pilot umano restano da eseguire. Goal `esegui` attivo.

| Repository | Base iniziale | Main riattestato |
|---|---|---|
| Kirchhoff, pubblico |`c778fd113cfe400f62d6c9858d3266e96be771f4`|`a3eb02bbeee7bc2914737f73cf771f524265c4c4`|
| Ardesia, privato |`b124eee04acc8062c27284f23c5d9108e3767c27`|invariato `b124eee04acc8062c27284f23c5d9108e3767c27`|

Archivio Ardesia conservato: `archive/codex-finalization-20261015` → `5b1f65779701ba680a9b4d7d0841dc9c021422ff`. Le patch locali sono unità separate, da integrare e verificare insieme: non rappresentano un main composito già collaudato.

| Unità | Candidato / branch | Decisione e prova |
|---|---|---|
| Kirchhoff: retry e link copiabile |`92149227`, PR25|MERGED; risposte obsolete e tastiera corretti|
| Kirchhoff: Ohm e riferimenti |`c5e34e03`, PR26|MERGED; R1 errato distinto da aritmetica errata, operandi portabili|
| Kirchhoff: cronologia tentativi/correzioni |`023fef3d`, PR27|MERGED; quaderno v3 e PDF ricalcolati alla riapertura|
| Ardesia: reader limitato |`b9bff962`, `codex/bounded-lesson-reader-20261016`|[PR262](https://github.com/AndreaMarro/ardesia/pull/262) OPEN, READY, REVIEW_REQUIRED; tutti i checkSUCCESS|
| Ardesia: re-ingest atomico |`6536991c`, `codex/atomic-reingest-20261016`|Locale su readerb9;2151PASS7SKIP offline, review favorevole|
| Ardesia: storage degradato visibile |`1842338b`, `codex/continuity-storage-20261016`|Locale su mainb124;2155PASS5SKIP, frozen2156PASS,12browserPASS|
| Ardesia: identità post-it/reload |`2c12ce93`, `codex/postit-reload-20261016`|Locale su mainb124;2158PASS5SKIP, frozen2159PASS,6browserPASS|
| Ardesia: LED/corrente non disponibili |`8c5d650a`, `codex/led-unknown-20261016`|Locale su mainb124;2185PASS5SKIP, frozen2186PASS,19browserPASS|

Nell'ultima unità un dato assente o un solve rifiutato mostrano `?`; zero reale rimane zero. Pannello Lab e canvas condividono la normalizzazione mono. Tre bundle esportati sul commit esatto riaprono in un contesto nuovo e conservano errore del corto o nuovo risultato zero. La prima review461 ha trovato tre lacune; quattro controprove RED permanenti hanno guidato i fix, poi controreview4PASS sul nuovo candidato.

[QA e limiti LED](ardesia-led-qa-8c5d650a.md) · [patch](ardesia-led-ignoto-8c5d650a.patch) · [prove, comandi, esiti e hash](ardesia-led-prove-8c5d650a.json) · [eventi e digesti](ardesia-led-trasporto-8c5d650a.json). Test rilevanti: consumer reali, zero/nonfinito, corto/undo, reload, export API e destinatario isolato; screenshot desktop/mobile ispezionati. Non è una prova di durabilità fisica o del flusso completo di export UI.

Kirchhoff main: Python CI2628PASS3SKIP,97.34% globale/dominio100%; web391unitPASS,186browserPASS62skip opzionali. Le prove live mirate sono state eseguite separatamente. [Quaderno main](dc-cronologia-quaderno-a3eb02b.json), [PDF10pagine](dc-cronologia-lezione-a3eb02b.pdf), [prova di riapertura](dc-cronologia-prova-a3eb02b.json). Locale2631PASS0SKIP97.40%; differenze e skip CI spiegati nelle [prove cronologia](kirchhoff-cronologia-prove-a3eb02b.json).

Ardesia reader: locale2109PASS7SKIP, CIengine2107PASS9SKIP/Studio2149PASS5SKIP. I cinque skip Studio delle unità locali dipendono da screenshot esterne assenti. Nessuna soglia, protezione, definizione Verified, skip, retry o timeout è stata allentata. Le review in contesti separati sono tecniche, non approvazioni umane GitHub. Le suite finali non cancellano gli esiti rossi precedenti, distinti dai guasti di setup.

Effetti remoti già compiuti: merge normali Kirchhoff25/26/27 e apertura/aggiornamento Ardesia262. In questa unità LED nessun push, nuova PR, merge o deploy esplicito. Le anteprime automatiche già registrate dalle integrazioni PR restano separate.

Incidente preservato: una verifica precedente del re-ingest atomico con chiavi ereditate ha attivato quattro test live, con richieste esterne involontarie e costo ignoto (2153PASS2FAIL3SKIP; due HTTP404 Kimi). Il successivo run offline verde non annulla quel FAIL. Nell'unità LED tutte e tre le chiavi provider erano escluse e non sono state osservate richieste provider; nessuna attestazione di costo zero per l'intero lavoro.

Restano: integrazione Ardesia dopo il gate umano, coerenza append/chiusura/materiale, collisione fra pipeline narrativa LLM e policy ZERO-LLM, percorso a due revisioni congelate e pilot umano reale. Una sola prossima unità prioritaria: **append accettate, fine lezione e materiale riferiti alla stessa revisione**, riusando store/eventi esistenti.

[Manifest completo](integrazione-baseline-20261016.json) · [mappa recupero Ardesia](recupero-ardesia-20261016.md) · [resoconto storico dettagliato](resoconto-dettagliato-pre-led-20261016.md). Toolchain ultima unità: Node24.19.0, gateNode26.5.1, Chromium148.0.7778.96, Playwright1.60.0, Vitest4.1.8, Vite8.0.16, TypeScript6.0.3. Codex basato suGPT-6; identificatore API esatto non esposto.
