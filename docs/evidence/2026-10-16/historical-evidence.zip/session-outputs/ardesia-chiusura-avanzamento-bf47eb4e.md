# Ardesia — chiusura e materiale: avanzamento locale

**IN CORSO.** Checkpoint `bf47eb4e134fe1cbd5e417035aa8b233e35b53ed`, tree `8e6af08323c93c79f90f4a5a0704238d3abd9184`, su main `b124eee04acc8062c27284f23c5d9108e3767c27`. Il percorso completo lezione → memoria → materiale della stessa revisione richiede ancora la cattura comune e il collegamento della schermata.

Le azioni accettate vengono drenate prima della fine lezione. Errori e ACK persi consentono un retry deliberato senza duplicare l'evento. Quando la fine potrebbe essere già salvata, il canvas rimane congelato. Il vecchio renderer perde la propria autorizzazione al cleanup. Materiali acquisisce l'archivio persistente fresco per ogni export e rende visibili i guasti; un log corrente vuoto non ripristina silenziosamente lo snapshot precedente.

Il riepilogo usa il journal della lezione, conserva testo finale e provenienza e distingue PDF importato da pagina osservata. Due successive review hanno trovato casi reali di durata/attività persa: import-only e metadati legacy validi senza adattatore canonico. Le controprove permanenti ora passano. La timeline conserva entrambi gli output accettati dal decoder, senza promuovere le evidenze. La controreview finale del delta ha 12 verifiche indipendenti passate, senza nuovi rilievi concreti nel perimetro.

| Prova | Esito |
|---|---|
| Suite completa sul codice salvato nel checkpoint | 2.203 PASS, cinque skip preesistenti, 84.03 s |
| Tipi e build del checkpoint | PASS |
| Review predecessore `3ac3574e` | 34 PASS indipendenti, nessun nuovo rilievo nel perimetro foundation/export |
| Browser sul predecessore `3ac3574e` | 6 PASS: desktop1440/mobile390; ritardo, rifiuto, ACK perso; domanda digitata, Simulation reale, export UI |

[Bundle dell'ACK perso](ardesia-chiusura-ack-perso-3ac3574e.lesson) · [Schermata mobile](ardesia-chiusura-ui-mobile-3ac3574e.png) · [Prove e hash](ardesia-chiusura-prove-bf47eb4e.json). I sei export browser riportano il producer `3ac3574e` nel manifest, negli eventi e nel journal. Lo screenshot mobile è stato ispezionato. I raw conservano l'etichetta prudenziale draft; il commit effettivo è verificato separatamente. Queste prove restano del predecessore; nessuna prova browser sul nuovo checkpoint è dichiarata.

La nuova lettura con esclusione usa il coordinatore esistente: autori attivi impediscono la cattura; nuove aperture e mutazioni attendono il rilascio. I test attuali usano il broker avversario esistente. La prova nativa fra due schede resta da eseguire; nei browser con esclusione solo locale non viene attestata coerenza fra schede.

Restano: cattura unica sotto quel lock, digest canonico per sessione, route read-only senza la propria attività Room, stessi byte per anteprima e download, materiale/PDF e destinatario riaperto. Gate frozen e review dell'intera unità rimangono pendenti. Nessun push, nuova PR, merge, CI o deploy in questo avanzamento. Integrazione Ardesia e pilot umano non eseguiti. All'ultima verifica PR262 era OPEN, check SUCCESS e review umana richiesta da GitHub.

Soglie, protezioni, schema persistito, solver e gate restano invariati. Le tre chiavi provider erano escluse: nessuna richiesta provider osservata in questa unità. L'incidente precedente dell'unità atomica, con richieste involontarie e costo ignoto, resta documentato. Errori di setup, RED e risultati intermedi sono conservati separatamente.
