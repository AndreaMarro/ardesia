# Ardesia: materiale chiuso — IN_PROGRESS, candidato locale

Base `b124eee04acc8062c27284f23c5d9108e3767c27`; checkpoint `14f68791aa0c3715989014d28a1efc29c9a0cbf5`, tree `92bdddb6877adca91895f274bbde80b89cedeec0`, branch `codex/lesson-close-revision-20261016`. Nessun push, nuova PR, merge o deploy. Il successore in lavorazione corregge stampa e impaginazione; i file qui consegnati sono del checkpoint congelato.

La prova reale mobile ha rinominato la lezione, scritto la domanda, inserito Simulation, aperto una seconda scheda e chiuso entrambe. Il riepilogo resta indisponibile mentre la seconda è attiva. Dopo la chiusura, la stessa cattura produce HTML e `.lesson`: sei eventi, due sessioni, due chiusure e due risultati registrati da15,3mA. Ogni producer indica lo SHA esatto. È lo stesso docente predefinito in due schede, non collaborazione remota fra persone autenticate.

Il destinatario in un contesto vuoto ha importato quel file dall’interfaccia, riaperto il recap dopo reload e riesportato eventi canonici identici: desktop1440×1000 PASS12,1s e mobile390×844 PASS24,7s, nessun pageerror. Node24.19.0 e Chromium148.0.7778.96 misurati nel destinatario. Browser plugin assente; usato Playwright del checkout con dipendenze bloccate. Due errori console per viewport identificano il pulsante inline bloccato dal sandbox, già presente nella baseline.

Prove e limiti dei gate:

| Controllo | Esito |
|---|---|
| TypeScript exact14f / build Vite8.0.16 | PASS / PASS21,34s, warning dimensione chunk preesistente |
| Intero file Room dopo barriere React |108PASS77,37s; diagnostica estesa108PASS40,90s |
| Full precedente acd |2202PASS,2FAIL,5SKIP,8 errori avvio worker; exit1,4590,21s |
| Full14f |Interrotto con SIGINT dopo un indicatore di errore; exit130, senza riepilogo finale o identità certificata del fallimento |
| Scenario browser completo30s |Dev0PASS/2FAIL; produzione0PASS/2FAIL per scadenza del budget; non promosso |
| Criterio separato destinatario, stesso limite30s |2PASS; non cancella i fallimenti precedenti |
| PDF effettivamente stampato dall’HTML scaricato |2 pagine: domanda, risultati, omissione e hash estratti; nessuna parola fuori pagina rilevata; render di entrambe ispezionati |

Il PDF usa IowanOldStyle, SFNS e Courier incorporati. pdfplumber0.11.9 e pypdfium2 5.14.0; avvisi FontBBox mancanti conservati nel log. Il primo tentativo di ispezione richiedeva fitz non installato: errore di setup, poi riuso delle librerie già incluse. Il testo è leggibile; il piè di pagina resta quasi isolato nella seconda pagina. La formula non è esercitata in questa fixture. Le figure sono omesse esplicitamente dall’HTML e conservate nel bundle: il materiale finale non è completo.

La review separata ha confermato le due correzioni del core e il delta fixture senza oracoli o timeout indeboliti. Ha identificato il P2 preesistente Stampa nell’iframe: il successore mantiene il sandbox, apre gli stessi byte dal parent e corregge la resa mobile/stampa. Nessuna review umana GitHub sostituita: #262 resta OPEN/BLOCKED per approvazione richiesta, con gli ultimi check SUCCESS. Le altre unità locali restano separate.

Comandi verificabili: Node24 `vitest run ... --pool=threads --maxWorkers=1 --no-file-parallelism --testTimeout=30000 --hookTimeout=30000 --teardownTimeout=30000`; `tsc -b`; `vite build`; `vite preview --host127.0.0.1 --port5195 --strictPort`; Playwright con config esterne e timeout30000, workers1, nessun retry. Le tre chiavi provider sono state rimosse dall’ambiente dei comandi; nessuna nuova chiamata a pagamento osservata. L’incidente precedente nell’unità atomic resta registrato con costo ignoto.

Prossima azione: completare la correzione stampa con prova nativa, poi risolvere il full non verde e le figure. Non attestati: durata fisica dopo crash, formule complete, verticale Kirchhoff–Ardesia composto, pilot umano.
