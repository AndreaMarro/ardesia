# ARDESIA — stato corrente

> **GENERATO** da `bin/state/project_state.py` il 2026-10-16T15:09:38+02:00.
> Non modificarlo a mano: la prossima esecuzione lo sovrascrive.
> La forma leggibile a macchina e' `artifacts/state/project.json` (non committato).

Questo file e' l'unica dichiarazione di stato corrente del repo. Ogni
altro documento in `docs/ops/` e' un **registro storico**: descrive
l'istante in cui e' stato scritto, non l'istante in cui lo leggi.

## Repo

- `main` (origin): **b124eee0**
- HEAD locale: `b124eee0` sul ramo `codex/documentation-closeout-20261016`
- file non committati nel checkout: 0

<sub>fonte: `git rev-parse HEAD | origin/main; git status --porcelain`</sub>

## Pull request aperte

- aperte: **0**
- `current` (base `main`, nessun omonimo piu' recente): **0**
- `superseded` (esiste un omonimo con numero maggiore): 0
- `stacked` (base = ramo di un'altra PR aperta): 0
- `orphan_base` (base non e' `main` e nessuna PR la possiede): 0

`mergeStateStatus` non entra in questa classificazione: `CLEAN`
contro una base morta non e' «pronta».

| PR | classe | base | titolo |
|---:|---|---|---|

<sub>fonte: `gh pr list --state open --limit 200 --json number,title,baseRefName,headRefName,mergeStateStatus,isDraft`</sub>

## Check richiesti

- richiesti su `main`: `studio (typecheck + test + build)`, `engine (pytest)`, `hygiene (NUL + secrets + boundary + whitespace)`
- strict: True

<sub>fonte: `gh api repos/AndreaMarro/ardesia/branches/main/protection`</sub>

## Deploy

- ultimo deploy (ricevuta): `3e170f838353181f8dab36da529377041418abc3`
- quando: 2026-07-31T01:30:00Z
- dove: https://ardesia-lavagna.vercel.app
- ricevuta pari a `main`: False · ricevute totali: 6

<sub>fonte: `docs/ops/deploys/2026-07-31T01-30Z-3e170f83.json`</sub>

- servito ADESSO dalla produzione: `b124eee04acc8062c27284f23c5d9108e3767c27`
- `prod_scarto` (servito ↔ `origin/main`): **0** commit indietro
- **pari a `main` in produzione: sì**
- letto da: `https://ardesia-lavagna.vercel.app/assets/index-D51Rbomr.js`

## Certificazione esperimenti

- corpus: **88** lesson path
- `candidate`: 4/88
- **certificati: 0/88**

<sub>fonte: `apps/studio/src/toolhost/elabExperimentCatalog.ts`</sub>

## Oracolo di prodotto (E2E)

- spec Playwright presenti: 103
- eseguite in CI: True
- golden path (`apps/studio/e2e/golden-path.spec.ts`) esiste: True

<sub>fonte: `rglob *.spec.{ts,tsx,js,mjs} e playwright.config.* (escluso node_modules); invocazione Playwright nei workflow, commenti rimossi`</sub>

