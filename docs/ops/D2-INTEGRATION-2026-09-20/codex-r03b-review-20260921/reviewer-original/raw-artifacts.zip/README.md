# R-03b independent review artifacts

- Candidate: `a90d3563014c5cd995630a37ea164f42f4c40b9c`
- Base: `b76611be7bcfd738d31c9b845a6be1acd95ded74`
- Reviewer runtime identity: `inherited/unknown`
- Capability receipt: `INDEX_SYNC_DEFERRED` because the current mandate forbids vault and memory access.

`run-scrubbed.sh` removes the five prohibited provider/browser environment names from every verification child process. Each command receives separate direct stdout, stderr, and metadata files.
