import datetime,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2]
name,cwd,*cmd=sys.argv[1:]
env=os.environ.copy()
for key in ("KIMI_API_KEY","DEEPSEEK_API_KEY","OPENAI_API_KEY","ANTHROPIC_API_KEY","ARDESIA_CHROMIUM_NO_SANDBOX"):
    env.pop(key,None)
start=time.time()
with (root/"artifacts/restart"/f"{name}.log").open("w") as out:
    result=subprocess.run(cmd,cwd=root/cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
record=dict(name=name,cwd=cwd,command=cmd,exit_code=result.returncode,seconds=round(time.time()-start,2),utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (root/"artifacts/restart/commands.jsonl").open("a") as out: out.write(json.dumps(record)+"\n")
print(json.dumps(record))
print((root/"artifacts/restart"/f"{name}.log").read_text()[-6500:])
sys.exit(result.returncode)
